package com.rest;

import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.after;

import static com.rest.JsonUtil.*;

public class sentence_controller {

    public sentence_controller(final sentence_service sentenceService) {

        get("/sentences/:id", (request, response) -> {
			String id = request.params(":id");
            try {
                int id_check = Integer.parseInt(id); 
                sentencewithcipher sentence = sentenceService.getSentence(id_check);
			if (sentence != null) {
                response.status(200);
				return sentence;
			}
            else 
            {
                response.status(404);
                return "Sentence not found";
            }
            }catch (Exception ex)
            {
                response.status(400);
                return "Invalid ID Supplied";
            }
			
		}, json());

        post("/sentences/", (request, response) -> {
            sentence sentence = sentenceService.createSentence(request.queryParams("id"),
            request.queryParams("name")); 
            if (sentence != null) 
            {
                response.status(200);
				return "Success";
            }
            else 
            {
                response.status(405);
                return "Error";
            }

		}, json());

        after((request, response) -> {
			response.type("application/json");
		});
        // more routes
      }
    
}
