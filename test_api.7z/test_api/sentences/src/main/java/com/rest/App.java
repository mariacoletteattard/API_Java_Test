package com.rest;

import static spark.Spark.port;

public class App {

    public static void main(String[] args) {

        port(8080);

        new sentence_controller(new sentence_service());
    }
}
