package com.rest;

import java.sql.DriverManager;
import java.util.Properties;

import java.sql.*;

public class sentence_service {

    final String dbURL = "jdbc:redshift://redshift-cluster-1.coro4e0fppwj.us-east-1.redshift.amazonaws.com:5439/dev";
    final String MasterUsername = "api_user";
    final String MasterUserPassword = "Test1345";

    public static String rot13(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= 'a' && c <= 'm')
                c += 13;
            else if (c >= 'A' && c <= 'M')
                c += 13;
            else if (c >= 'n' && c <= 'z')
                c -= 13;
            else if (c >= 'N' && c <= 'Z')
                c -= 13;
            sb.append(c);
        }
        return sb.toString();
    }

    public sentencewithcipher getSentence(int sentenceId) {

        Connection conn = null;
        Statement stmt = null;
        sentencewithcipher currentSentence = new sentencewithcipher();

        try {
            Class.forName("com.amazon.redshift.jdbc42.Driver");

            Properties props = new Properties();

            props.setProperty("user", MasterUsername);
            props.setProperty("password", MasterUserPassword);
            conn = DriverManager.getConnection(dbURL, props);

            stmt = conn.createStatement();
            String sql = "select name from smg_test.sentences where id = " + sentenceId + ";";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next() == false) {
                currentSentence = null; 
            } else {
                do {
                    currentSentence.cyphered_text = rot13(rs.getString("name"));
                    currentSentence.name = rs.getString("name");  
                    currentSentence.id = sentenceId;
                } while (rs.next());
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            currentSentence.id = -1;
        }
        return currentSentence;
    }

    public sentence createSentence(String sentenceId, String name) {
       
        Connection conn = null;
        PreparedStatement stmt = null;
        int sentenceId_int = 0; 
        sentence currentSentence = new sentence();

        try {
            Class.forName("com.amazon.redshift.jdbc42.Driver");

            Properties props = new Properties();

            sentenceId_int = Integer.parseInt(sentenceId);

            props.setProperty("user", MasterUsername);
            props.setProperty("password", MasterUserPassword);
            conn = DriverManager.getConnection(dbURL, props);

       
            //String sql = "insert into smg_test.sentences values (" + sentenceId_int + ", '" + name + "');";
            String sql = "insert into smg_test.sentences values (?, ?);"; 
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, sentenceId_int);
            stmt.setString(2, name);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
            currentSentence.id = sentenceId_int; 
            currentSentence.name = name; 
        } catch (Exception e) {
            currentSentence = null; 
        }
        return currentSentence;

    }


}
