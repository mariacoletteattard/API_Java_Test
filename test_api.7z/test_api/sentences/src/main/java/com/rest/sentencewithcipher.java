package com.rest;

public class sentencewithcipher {

    int id;
    String name;
    String cyphered_text; 

    public sentencewithcipher(int id, String name, String cyphered_text) {
        this.id = id;
        this.name = name;
        this.cyphered_text = cyphered_text; 
    }

    public sentencewithcipher() 
    {
        this.id = -1; 
        this.name = ""; 
        this.cyphered_text = "";
 
    }
    
}
