package com.rest;

public class sentence {

    int id;
    String name;
    int resultCode;

    public sentence(int id, String name, int resultCode) {
        this.id = id;
        this.name = name;
        this.resultCode = resultCode;
    }

    public sentence() 
    {
        this.id = -1; 
        this.name = ""; 
        this.resultCode = -1; 

    }
    
}
